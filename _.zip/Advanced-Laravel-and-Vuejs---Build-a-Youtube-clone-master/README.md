## $5 Tech Unlocked 2021!
[Buy and download this Video for only $5 on PacktPub.com](https://www.packtpub.com/product/advanced-laravel-and-vue-js-build-a-youtube-clone-video/9781800200449)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# Advanced-Laravel-and-Vuejs---Build-a-Youtube-clone
Advanced Laravel and Vuejs - Build a Youtube clone by Packt Publishing
