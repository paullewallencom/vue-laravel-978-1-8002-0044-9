<?php

namespace Laratube;

class Subscription extends Model
{
    //
}
